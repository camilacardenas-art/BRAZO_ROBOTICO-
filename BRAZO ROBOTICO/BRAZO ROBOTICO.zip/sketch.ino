#include <WiFi.h>

const char* ssid = "Wokwi-GUEST";
const char* password = "";

WiFiServer server(80);

void setup() {
  Serial.begin(115200);

  WiFi.begin(ssid, password);
  Serial.print("Conectando a WiFi Wokwi...");
  while (WiFi.status() != WL_CONNECTED) {
    delay(250);
    Serial.print(".");
  }
  Serial.println("\nWiFi Conectado!");
  
  server.begin();
  Serial.println("Servidor TCP listo en el puerto 80!");
}

void loop() {
  // Esperar a que Python se conecte
  WiFiClient client = server.available();
  
  if (client) {
    Serial.println("¡Python se conectó al socket!");
    
    while (client.connected()) {
      float t = millis() / 1000.0;
      
      // Generar ángulos
      int j1 = (int)(90.0 * sin(t)); 
      int j2 = (int)(60.0 * cos(t * 0.8));
      float gripper = 0.02 + 0.02 * sin(t * 1.5);

      // Crear la trama
      String trama = String(j1) + "," + String(j2) + "," + String(gripper, 3) + "\n";

      // Enviar a Python por red
      client.print(trama);
      
      // Imprimir en la consola web para verificación visual
      Serial.print("Enviando: ");
      Serial.print(trama);

      delay(50); // 20 envíos por segundo
    }
    
    client.stop();
    Serial.println("Python se desconectó.");
  }
}